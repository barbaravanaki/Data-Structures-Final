
import java.util.Scanner;
import java.util.ArrayList;

public class ItemMaintApp implements ItemConstants {

    // declare two class variables
    private static ItemDAO itemDAO = null;
    private static Scanner sc = null;

    public static void main(String args[]) {
        // display a welcome message
        System.out.println("Welcome to the Item Maintenance application\n");

        // set the class variables
        itemDAO = DAOFactory.getItemDAO();
        sc = new Scanner(System.in);

        // display the command menu
        displayMenu();

        // perform 1 or more actions
        String action = "";
        while (!action.equalsIgnoreCase("exit")) {
            // get the input from the user
            action = Validator.getString(sc,
                    "Enter a command: ");
            System.out.println();

            if (action.equalsIgnoreCase("list")) {
                displayAllItems();
            } else if (action.equalsIgnoreCase("add")) {
                addItem();
            } else if (action.equalsIgnoreCase("del") || action.equalsIgnoreCase("delete")) {
                deleteItem();
            } else if (action.equalsIgnoreCase("update")) {
                updateItem();
            } else if (action.equalsIgnoreCase("help") || action.equalsIgnoreCase("menu")) {
                displayMenu();
            } else if (action.equalsIgnoreCase("exit")) {
                System.out.println("Bye.\n");
            } else {
                System.out.println("Error! Not a valid command.\n");
            }
        }
    }

    public static void displayMenu() {
        System.out.println("COMMAND MENU");
        System.out.println("list    - List all items");
        System.out.println("add     - Add a item");
        System.out.println("del     - Delete a item");
        System.out.println("update - update a item");
        System.out.println("help    - Show this menu");
        System.out.println("exit    - Exit this application\n");
    }

    public static void displayAllItems() {
        System.out.println("ITEM LIST");

        ArrayList<Item> items = itemDAO.getItems();
        if (items == null) {
            System.out.println("Error! Unable to get items.\n");
        } else {
            Item p = null;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < items.size(); i++) {
                p = items.get(i);
                sb.append(
                         StringUtils.padWithSpaces(
                                p.getCode(), CODE_SIZE + 4)
                        + StringUtils.padWithSpaces(
                                p.getDescription(), DESCRIPTION_SIZE + 4)
                        + StringUtils.padWithSpaces(
                                p.getAmountString(), CODE_SIZE + 4)
                        + p.getFormattedPrice() + "\t"
                        + p.getDiscount() + "\n"
						+ StringUtils.padWithSpaces(
                                p.getCompany(), DESCRIPTION_SIZE + 4)
                );
            }
            System.out.println(sb.toString());
        }
    }

    public static void addItem() {
        
        String code = Validator.getString(
                sc, "Enter item code: ");
       
        String description = Validator.getLine(
                sc, "Enter item description: ");
				
        int amount = Validator.getInt(
                sc, "Enter item amount: ");
				
        double price = Validator.getDouble(
                sc, "Enter price: ");
				
        char discount = Validator.getChar(
                sc, "Enter does the item has discount: ");
				
				
		String company = Validator.getLine(
                sc, "Enter the company: ");
				

        Item item = new Item();
      
        item.setCode(code); 
        item.setDescription(description);
        item.setAmount(amount);
        item.setPrice(price);
        item.setDiscount(discount);
		
		 item.setCompany(company);
		
        boolean success = itemDAO.addItem(item);

        System.out.println();
        if (success) {
            System.out.println(description
                    + " was added to the database.\n");
        } else {
            System.out.println("Error! Unable to add item\n");
        }
    }

    public static void deleteItem() {
        String code = Validator.getString(sc,
                "Enter item code to delete: ");

        Item p = itemDAO.getItem(code);

        System.out.println();
        if (p != null) {
            boolean success = itemDAO.deleteItem(p);
            if (success) {
                System.out.println(p.getDescription()
                        + " was deleted from the database.\n");
            } else {
                System.out.println("Error! Unable to add item\n");
            }
        } else {
            System.out.println("No item matches that code.\n");
        }
    }

    public static void updateItem() {
        
        String code = Validator.getString(
                sc, "Enter item code: ");
        String description = Validator.getLine(
                sc, "Enter item description: ");
        int amount = Validator.getInt(
                sc, "Enter item amount: ");
        double price = Validator.getDouble(
                sc, "Enter price: ");
        char discount = Validator.getChar(
                sc, "Enter does the item has discount: ");
				
				String company = Validator.getLine(
                sc, "Enter the company: ");

        Item item = new Item();
        
        item.setCode(code);
        item.setDescription(description);
        item.setAmount(amount);
        item.setPrice(price);
        item.setDiscount(discount);
		
		item.setCompany(company);
		
        boolean success = itemDAO.updateItem(item);

        System.out.println();
        if (success) {
            System.out.println(description
                    + " was added to the database.\n");
        } else {
            System.out.println("Error! Unable to add item\n");
        }
    }

}
