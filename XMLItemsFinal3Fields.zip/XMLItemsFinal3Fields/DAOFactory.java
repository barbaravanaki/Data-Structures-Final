public class DAOFactory
{
	// this method maps the ItemDAO interface
	// to the appropriate data storage mechanism
	public static ItemDAO getItemDAO()
	{
		ItemDAO pDAO = new ItemXMLFile();
		return pDAO;
	}
}