import java.util.ArrayList;

public interface ItemReader
{
	Item getItem(String code);
	ArrayList<Item> getItems();
}