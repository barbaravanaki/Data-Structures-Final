
import java.text.NumberFormat;

public class Item {

    private String code;

    private String description;
    private int amount;
    private double price;
    private char discount;
	
	private String company;

    public Item() {
        this("", "", 0, 0.0, ' ',"");
    }

    public Item( String code, String description, int amount, double price, char discount,String company) {
        
        this.code = code;
        
        this.description = description;
        this.amount = amount;
        this.price = price;
        this.discount = discount;
		this.company = company;
    }

   

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

   public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }

    public String getAmountString() {
        String amountString = Integer.toString(amount);
        return amountString;

    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public String getFormattedPrice() {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(price);
    }

    public void setDiscount(char discount) {
        this.discount = discount;
    }

    public char getDiscount() {
        return discount;
    }

	
	
	 public void setCompany(String company) {
        this.company = company;
    }

    public String getCompany() {
        return company;
    }
	
	
	
	
	
	
    public boolean equals(Object object) {
        if (object instanceof Item) {
            Item item2 = (Item) object;
            if ( code.equals(item2.getCode())
                    && description.equals(item2.getDescription())
                    && amount == item2.getAmount()
                    && price == item2.getPrice()
                    && discount == item2.getDiscount()
					&& company.equals(item2.getCompany())
					) {
                return true;
            }
        }
        return false;
    }

    public String toString() {
        return "Code:        " + code + "\n"
                + "Description: " + description + "\n"
                + "amount:   " + amount + "\n"
                + "Price:       " + this.getFormattedPrice() + "\n"
                + "discount:    " + discount
				+  "company is   " + company;
			
    }
}
