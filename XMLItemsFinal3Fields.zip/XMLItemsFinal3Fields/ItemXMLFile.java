
import java.util.*;
import java.io.*;
import javax.xml.stream.*;  // StAX API

public class ItemXMLFile implements ItemDAO {

    private String itemsFilename = "items.xml";
    private File itemsFile = null;

    public ItemXMLFile() {
        itemsFile = new File(itemsFilename);
    }

    private void checkFile() throws IOException {
        // if the file doesn't exist, create it
        if (!itemsFile.exists()) {
            itemsFile.createNewFile();
        }
    }

    private boolean saveItems(ArrayList<Item> items) {
        // create the XMLOutputFactory object
        XMLOutputFactory outputFactory = XMLOutputFactory.newInstance();

        try {
            // check the file to make sure it exists
            this.checkFile();

            // create XMLStreamWriter object
            FileWriter fileWriter
                    = new FileWriter(itemsFilename);
            XMLStreamWriter writer
                    = outputFactory.createXMLStreamWriter(fileWriter);

            //write the items to the file
            writer.writeStartDocument("1.0");
            writer.writeStartElement("Items");
            for (Item p : items) {

                writer.writeStartElement("Item");
                writer.writeAttribute("Code", p.getCode());

                

                writer.writeStartElement("Description");
                writer.writeCharacters(p.getDescription());
                writer.writeEndElement();

                
				
				
				
				writer.writeStartElement("Amount");
                int amount = (int) p.getAmount();
                writer.writeCharacters(Integer.toString(amount));
                writer.writeEndElement();

                
				
				
				writer.writeStartElement("Price");
                double price = p.getPrice();
                writer.writeCharacters(Double.toString(price));
                writer.writeEndElement();

                
				
				
				writer.writeStartElement("Discount");
                char discount = p.getDiscount();
                writer.writeCharacters(Character.toString(discount));
                writer.writeEndElement();
				
				
				
			
				
				
				writer.writeStartElement("Company");
                writer.writeCharacters(p.getCompany());
                writer.writeEndElement();
				
				
				

                writer.writeEndElement();
            }
          
   		  writer.writeEndElement();
            writer.flush();
            writer.close();
			
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } catch (XMLStreamException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public ArrayList<Item> getItems() {
        ArrayList<Item> items = new ArrayList<Item>();
        Item p = null;

        // create the XMLInputFactory object
        XMLInputFactory inputFactory = XMLInputFactory.newInstance();
        try {
            // check the file to make sure it exists
            this.checkFile();

            // create a XMLStreamReader object
            FileReader fileReader
                    = new FileReader(itemsFilename);
            XMLStreamReader reader
                    = inputFactory.createXMLStreamReader(fileReader);

            // read the items from the file
            while (reader.hasNext()) {
                int eventType = reader.getEventType();
                switch (eventType) {
                    case XMLStreamConstants.START_ELEMENT:
                        String elementName = reader.getLocalName();
                        if (elementName.equals("Item")) {
                            p = new Item();
 
                            String code = reader.getAttributeValue(0);
                            p.setCode(code);
                        }
                        

                        if (elementName.equals("Description")) {
                            String description = reader.getElementText();
                            p.setDescription(description);
                        }
                        
						
						
						
						
						if (elementName.equals("Amount")) {
                            String AmountString = reader.getElementText();
                            int amount = Integer.parseInt(AmountString);
                            p.setAmount(amount);
                        }

                        
						
						
						if (elementName.equals("Price")) {
                            String priceString = reader.getElementText();
                            double price = Double.parseDouble(priceString);
                            p.setPrice(price);
                        }
                        
						
						if (elementName.equals("Discount")) {
                            String discountString = reader.getElementText();
                            char discount = discountString.charAt(0);
                            p.setDiscount(discount);
                        }
						
						
						
						if (elementName.equals("Company")) {
                            String description = reader.getElementText();
                            p.setDescription(description);
                        }
						
						
						
						

                        break;
                    case XMLStreamConstants.END_ELEMENT:
                        elementName = reader.getLocalName();
                        if (elementName.equals("Item")) {
                            items.add(p);
                        }
                        break;
                    default:
                        break;
                }
                reader.next();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (XMLStreamException e) {
            e.printStackTrace();
            return null;
        }
        return items;
    }

    public Item getItem(String code) {
        ArrayList<Item> items = this.getItems();
        for (Item p : items) {
            if (p.getCode().equals(code)) {
                return p;
            }
        }
        return null;
    }

    public boolean addItem(Item p) {
        ArrayList<Item> items = this.getItems();
        items.add(p);
        return this.saveItems(items);
    }

    public boolean deleteItem(Item p) {
        ArrayList<Item> items = this.getItems();
        items.remove(p);
        return this.saveItems(items);
    }

    public boolean updateItem(Item newItem) {
        ArrayList<Item> items = this.getItems();

        // get the old item and remove it
        Item oldItem = this.getItem(newItem.getCode());
        int i = items.indexOf(oldItem);
        items.remove(i);

        // add the updated item
        items.add(i, newItem);

        return this.saveItems(items);
    }
}
