public interface ItemWriter
{
	boolean addItem(Item p);
	boolean updateItem(Item p);
	boolean deleteItem(Item p);
}