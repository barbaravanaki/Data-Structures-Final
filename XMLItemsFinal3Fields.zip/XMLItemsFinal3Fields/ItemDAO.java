public interface ItemDAO extends ItemReader, ItemWriter, ItemConstants
{
	// all methods from the ItemReader and ItemWriter interfaces
	// all static constants from the ItemConstants interface
}