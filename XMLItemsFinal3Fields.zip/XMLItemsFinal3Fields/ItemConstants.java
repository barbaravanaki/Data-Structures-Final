public interface ItemConstants
{
	int CODE_SIZE = 4;
	int DESCRIPTION_SIZE = 20;
}